"""Part III: moisture, motion and weather maps. Every equation of Part III as a function."""
import math

G = 9.81
R_D = 287.0
OMEGA = 7.292e-5
TABLE_PRESSURE_HPA = 995.5


def saturation_vapour_pressure(t_c):
    """Saturation vapour pressure (hPa) over water at t_c (deg C)."""
    return 6.112 * math.exp(17.67 * t_c / (t_c + 243.5))


def saturation_mixing_ratio(t_c, p_hpa=TABLE_PRESSURE_HPA):
    """Saturation mixing ratio (g/kg) at t_c and p_hpa."""
    e_s = saturation_vapour_pressure(t_c)
    return 622.0 * e_s / (p_hpa - e_s)


def relative_humidity(w, w_s):
    """Relative humidity (%) from the mixing ratio and the saturation mixing ratio."""
    return 100.0 * w / w_s


def mixing_ratio_from_rh(w_s, rh):
    """Mixing ratio (g/kg) from the saturation mixing ratio and the relative humidity (%)."""
    return w_s * rh / 100.0


def vapour_pressure(w, p_hpa=TABLE_PRESSURE_HPA):
    """Vapour pressure (hPa) from the mixing ratio (g/kg)."""
    return w * p_hpa / (622.0 + w)


def dew_point(w, p_hpa=TABLE_PRESSURE_HPA):
    """Dew point (deg C) from the mixing ratio (g/kg)."""
    x = math.log(vapour_pressure(w, p_hpa) / 6.112)
    return 243.5 * x / (17.67 - x)


def rh_rule_of_thumb(t_c, t_d):
    """Approximate relative humidity (%) from the temperature and the dew point."""
    return 100.0 - 5.0 * (t_c - t_d)


def cloud_base(t_c, t_d):
    """Approximate height of the cloud base (m)."""
    return 125.0 * (t_c - t_d)


def thickness(mean_t_k, p1_hpa, p2_hpa):
    """Hypsometric equation: thickness (m) of the layer between two pressures."""
    return R_D * mean_t_k / G * math.log(p1_hpa / p2_hpa)


def coriolis_parameter(lat_deg):
    """Coriolis parameter (per second) at a latitude."""
    return 2.0 * OMEGA * math.sin(math.radians(lat_deg))


def geostrophic_wind(dz_m, dn_m, lat_deg):
    """Geostrophic wind (m/s) from the height change of a pressure surface over a distance."""
    return G / coriolis_parameter(lat_deg) * dz_m / dn_m


def fahrenheit_to_celsius(t_f):
    """Temperature in deg C from deg F."""
    return (t_f - 32.0) * 5.0 / 9.0


def decode_pressure(code):
    """Sea-level pressure (hPa) from a three-digit station-model code."""
    return (1000.0 if code < 500 else 900.0) + code / 10.0


def knots_to_ms(knots):
    """Wind speed in m/s from knots."""
    return 0.514 * knots
