"""Part II: solar radiation. Every equation of Part II as a function."""
import math

WIEN_C = 2898.0
SIGMA = 5.67e-8
S_EARTH = 1368.0
KELVIN_OFFSET = 273.16


def wien_temperature(peak_um):
    """Black-body temperature (K) from the wavelength of peak emission (micrometres)."""
    return WIEN_C / peak_um


def wien_peak(t_k):
    """Wavelength of peak emission (micrometres) at temperature t_k."""
    return WIEN_C / t_k


def emission(t_k):
    """Stefan-Boltzmann law: emission (W per square metre) at temperature t_k."""
    return SIGMA * t_k ** 4


def temperature_from_emission(e_wm2):
    """Stefan-Boltzmann law turned round: temperature (K) from emission."""
    return (e_wm2 / SIGMA) ** 0.25


def solar_constant(d_au):
    """Inverse-square law: sunlight at d_au from the Sun (W per square metre)."""
    return S_EARTH / d_au ** 2


def planet_temperature(s_wm2, albedo):
    """Black-body temperature (K) of a planet: incoming sunlight balances its emission."""
    return (s_wm2 * (1 - albedo) / (4 * SIGMA)) ** 0.25


def absorbed(incoming_wm2, albedo):
    """The part of the incoming radiation that is not reflected (W per square metre)."""
    return incoming_wm2 * (1 - albedo)


def zenith_angle(latitude_deg, declination_deg):
    """Noon zenith angle (degrees) at a latitude for a solar declination."""
    return abs(latitude_deg - declination_deg)


def sun_angle(zenith_deg):
    """Sun angle above the horizon (degrees)."""
    return 90.0 - zenith_deg


def beam_spreading(sun_deg):
    """Length of ground covered by a beam one unit wide."""
    return 1.0 / math.sin(math.radians(sun_deg))


def intensity_percent(sun_deg):
    """Solar intensity as a percentage per unit of ground."""
    return 100.0 / beam_spreading(sun_deg)
