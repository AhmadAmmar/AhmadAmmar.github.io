"""Part I: the vertical structure of the atmosphere. Every equation of Part I as a function."""
import json
import math
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data" / "part1.json"
HALVING_KM = 5.6
R_D = 287.0
C_P = 1004.0
G = 9.81


def load_data():
    """Return the soundings and profiles used in Part I."""
    return json.loads(DATA.read_text(encoding="utf8"))


def fraction_above(z_km, halving_km=HALVING_KM):
    """Fraction of the atmosphere above height z_km: half for every halving_km."""
    return 2 ** (-z_km / halving_km)


def pressure_halving(z_km, p0_hpa=1000.0):
    """Pressure (hPa) at z_km by the halving rule."""
    return p0_hpa * fraction_above(z_km)


def partial_pressure(p_hpa, gas_fraction=0.21):
    """Partial pressure (hPa) of a gas that makes up gas_fraction of the molecules."""
    return gas_fraction * p_hpa


def standard_temperature(z_km):
    """Standard-atmosphere temperature (deg C): 15 - 6.5 z up to 11 km, then constant."""
    return 15.0 - 6.5 * min(z_km, 11.0)


def lapse_rate(t_lower, t_upper, z_lower_m, z_upper_m):
    """Lapse rate (deg C per km). Positive: cooler with height. Negative: an inversion."""
    return (t_lower - t_upper) / ((z_upper_m - z_lower_m) / 1000.0)


def tropopause(z_m, t_c, limit=2.0, depth_m=2000.0, start_m=5000.0):
    """WMO tropopause: the lowest level above start_m where the lapse rate falls to the limit
    or less and the mean lapse rate to every level within depth_m above stays at or below it."""
    for i in range(len(z_m) - 1):
        if z_m[i] < start_m:
            continue
        if lapse_rate(t_c[i], t_c[i + 1], z_m[i], z_m[i + 1]) > limit:
            continue
        above = [j for j in range(i + 1, len(z_m)) if z_m[j] - z_m[i] <= depth_m]
        if all(lapse_rate(t_c[i], t_c[j], z_m[i], z_m[j]) <= limit for j in above):
            return z_m[i], t_c[i]
    return None


def scale_height_from_data(p1_hpa, p2_hpa, dz_km):
    """Scale height (km) from two pressures dz_km apart."""
    return dz_km / math.log(p1_hpa / p2_hpa)


def dry_adiabatic_lapse_rate():
    """Dry adiabatic lapse rate (deg C per km): g / c_p."""
    return G / C_P * 1000.0


def potential_temperature(t_c, p_hpa):
    """Potential temperature (K) of air at t_c (deg C) and p_hpa."""
    return (t_c + 273.15) * (1000.0 / p_hpa) ** (R_D / C_P)
