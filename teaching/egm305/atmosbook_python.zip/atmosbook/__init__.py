"""Functions and data for the atmosphere book."""
