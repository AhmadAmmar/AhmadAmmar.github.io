"""Known answers for Part II, as worked in the chapters."""
import pytest

from atmosbook import part2 as P


def test_q1_sun():
    assert P.wien_temperature(0.5) == 5796
    assert P.wien_temperature(0.5) - P.KELVIN_OFFSET == pytest.approx(5522.84)


def test_q2_emission():
    assert P.emission(5796) == pytest.approx(6.399e7, rel=1e-3)
    assert P.emission(14 + P.KELVIN_OFFSET) == pytest.approx(385.5, abs=0.1)


def test_q2_ratios():
    assert 5796 / 287.16 == pytest.approx(20.2, abs=0.05)
    assert P.emission(5796) / P.emission(287.16) == pytest.approx((5796 / 287.16) ** 4)


@pytest.mark.parametrize("d,s", [(1, 1368), (1.52, 592), (0.39, 8994)])
def test_inverse_square(d, s):
    assert P.solar_constant(d) == pytest.approx(s, abs=0.5)


def test_venus_absorbs():
    assert P.absorbed(2639, 0.9) == pytest.approx(263.9)


def test_venus_measured_albedo():
    assert P.planet_temperature(2639, 0.77) == pytest.approx(227, abs=1)


def test_q4_reflected():
    assert 1368 - P.absorbed(1368, 0.3) == pytest.approx(410.4)
    assert P.absorbed(1368, 0.3) == pytest.approx(957.6)


def test_q4_no_atmosphere():
    assert P.absorbed(341, 0.3) == pytest.approx(238.7)
    assert P.temperature_from_emission(P.emission(254.0)) == pytest.approx(254.0)


@pytest.mark.parametrize("lat,dec,zen", [(30, 23.5, 6.5), (60, 23.5, 36.5), (60, -23.5, 83.5), (30, -23.5, 53.5)])
def test_zenith(lat, dec, zen):
    assert P.zenith_angle(lat, dec) == pytest.approx(zen)


def test_q5_spreading():
    assert P.beam_spreading(6.5) == pytest.approx(8.834, abs=0.001)
    assert P.beam_spreading(53.5) == pytest.approx(1.244, abs=0.001)
    assert P.intensity_percent(6.5) == pytest.approx(11.3, abs=0.05)
    assert P.intensity_percent(53.5) == pytest.approx(80.4, abs=0.05)


def test_q5c():
    assert P.intensity_percent(36.5) - P.intensity_percent(6.5) == pytest.approx(48.2, abs=0.05)
    assert P.intensity_percent(53.5) / P.intensity_percent(6.5) == pytest.approx(7.1, abs=0.05)
