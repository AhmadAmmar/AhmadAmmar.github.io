"""Known answers for Part III, as worked in the chapters and read from its table."""
import pytest

from atmosbook import part3 as P


@pytest.mark.parametrize("t,e", [(0, 6.11), (20, 23.4), (40, 73.8)])
def test_es(t, e):
    assert P.saturation_vapour_pressure(t) == pytest.approx(e, rel=0.005)


@pytest.mark.parametrize("t,w", [(0, 3.84), (-8, 2.099), (10, 7.762), (14, 10.14), (26, 21.734), (34, 35.134)])
def test_ws_matches_table(t, w):
    assert P.saturation_mixing_ratio(t) == pytest.approx(w, rel=0.002)


def test_q6():
    w = P.mixing_ratio_from_rh(35.134, 62)
    assert w == pytest.approx(21.78, abs=0.005)
    assert P.dew_point(w) == pytest.approx(26.0, abs=0.1)


def test_q5():
    assert P.dew_point(10) == pytest.approx(13.8, abs=0.1)


def test_rule_of_thumb():
    assert P.rh_rule_of_thumb(34, 26) == 60


def test_rh():
    assert P.relative_humidity(7.5, 7.762) == pytest.approx(97, abs=0.5)


def test_thicker_when_warmer():
    assert P.thickness(280, 850, 300) > P.thickness(260, 850, 300)
    assert P.thickness(273.15, 1000, 500) == pytest.approx(287 * 273.15 / 9.81 * 0.6931, rel=1e-3)


def test_coriolis_antisymmetric():
    assert P.coriolis_parameter(45) == pytest.approx(1.031e-4, abs=1e-7)
    assert P.coriolis_parameter(-45) == pytest.approx(-P.coriolis_parameter(45))


def test_geostrophic():
    assert P.geostrophic_wind(60, 5e5, 45) == pytest.approx(11.4, abs=0.05)


@pytest.mark.parametrize("f,c", [(32, 0), (212, 100), (50, 10)])
def test_f_to_c(f, c):
    assert P.fahrenheit_to_celsius(f) == pytest.approx(c)


@pytest.mark.parametrize("code,p", [(247, 1024.7), (987, 998.7), (24, 1002.4)])
def test_decode(code, p):
    assert P.decode_pressure(code) == pytest.approx(p)
