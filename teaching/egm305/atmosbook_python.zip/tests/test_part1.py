"""Known answers for Part I, each worked by hand from the definitions or read from the data."""
import math

import pytest

from atmosbook import part1 as P

D = P.load_data()


@pytest.mark.parametrize("z,pct", [(0, 100), (5.6, 50), (11.2, 25), (16.8, 12.5), (50.4, 100 / 512)])
def test_halving(z, pct):
    assert 100 * P.fraction_above(z) == pytest.approx(pct)


@pytest.mark.parametrize("z,p", [(8.848, 334), (12, 226.4), (2.43, 740), (21.027, 74)])
def test_q3_pressures(z, p):
    assert P.pressure_halving(z) == pytest.approx(p, abs=0.5)


def test_q4_jet_oxygen():
    assert P.partial_pressure(P.pressure_halving(12)) == pytest.approx(47.6, abs=0.05)


@pytest.mark.parametrize("z,t", [(0, 15), (1, 8.5), (2, 2), (4, -11), (6, -24), (8, -37), (10, -50), (11, -56.5), (16, -56.5)])
def test_standard(z, t):
    assert P.standard_temperature(z) == pytest.approx(t)


def test_lapse_sign():
    assert P.lapse_rate(10, 4, 0, 1000) == 6
    assert P.lapse_rate(-1.25, -1.05, 1358, 1503) < 0


def test_q9():
    h = D["hillsborough"]
    g = P.lapse_rate(h["t"][0], -51.05, h["z"][0], 9383)
    assert g == pytest.approx(62.10 / 9.345)
    assert g == pytest.approx(6.65, abs=0.005)


@pytest.mark.parametrize("key,z,t", [("hillsborough", 9383, -51.05), ("st_johns", 11482, -62.05), ("florida", 16000, -75.6)])
def test_tropopauses(key, z, t):
    s = D[key]
    assert P.tropopause(s["z"], s["t"]) == (z, t)


def test_q12_drops():
    s = D["st_johns"]
    p = dict(zip(s["z"], s["p"]))
    assert p[140] - p[3006] == 305
    assert p[23834] - p[26404] == 10


def test_scale_height_recovers_halving():
    assert P.scale_height_from_data(1000, 500, 5.6) == pytest.approx(5.6 / math.log(2))


def test_dalr():
    assert P.dry_adiabatic_lapse_rate() == pytest.approx(9.77, abs=0.01)


def test_theta_at_1000hpa_is_kelvin():
    assert P.potential_temperature(15, 1000) == pytest.approx(288.15)


def test_data_is_as_tabulated():
    assert len(D["hillsborough"]["z"]) == len(D["st_johns"]["z"]) == 20
    assert D["florida"]["t"][8] == -75.6


def test_tropopause_needs_the_start_height():
    s = D["st_johns"]
    assert P.tropopause(s["z"], s["t"], start_m=0)[0] == 140
